#include "Application.h"

int main(int argc,char** argv)
{
	VGameEngine::Application app;
	app.InitialApp();
	app.ShutDownApp();
	return 0;
}