#pragma once

#include "Platform.h"

#define ID_FIRSTCHILD  100 
#define ID_SECONDCHILD 101 
#define ID_THIRDCHILD  102 
#define FULLSCREEN 0

namespace VGameEngine
{
	static class Application
	{
	private:
		void InitOSWindow();
		void ShutDownOSWidnow();

#if VK_USE_PLATFORM_WIN32_KHR
		HWND hwndMain;
		static HINSTANCE appInstance;
#endif

	public:
		Application(){}
		void InitialApp();
		void ShutDownApp();

#if VK_USE_PLATFORM_WIN32_KHR
		HINSTANCE& InstanceHandle() { return appInstance; }
		HWND& WindowHandleMain() { return hwndMain; }
#endif
	};
}

