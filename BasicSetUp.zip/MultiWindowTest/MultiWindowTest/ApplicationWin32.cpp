#include "Application.h"
#include "Platform.h"

namespace VGameEngine
{

#if VK_USE_PLATFORM_WIN32_KHR

	const char CLASS_NAME[] = "MainWindow";
	const char TITLE[] = "VGameEngine";
	UINT WIDTH = 800;
	UINT HEIGHT = 600;
	HWND hwndMain;
	HINSTANCE appInstance;

	BOOL CALLBACK EnumChildProc(HWND hwndChild, LPARAM lParam)
	{
		LPRECT rcParent;
		int i, idChild;

		// Retrieve the child-window identifier. Use it to set the 
		// position of the child window. 

		idChild = GetWindowLong(hwndChild, GWL_ID);

		if (idChild == ID_FIRSTCHILD)
			i = 0;
		else if (idChild == ID_SECONDCHILD)
			i = 1;
		else
			i = 2;

		// Size and position the child window.  

		rcParent = (LPRECT)lParam;
		MoveWindow(hwndChild,
			(rcParent->right / 3) * i,
			0,
			rcParent->right / 3,
			rcParent->bottom,
			TRUE);

		// Make sure the child window is visible. 

		ShowWindow(hwndChild, SW_SHOW);

		return TRUE;
	}

	LRESULT WINAPI MainWndProc(HWND _hwndMain, UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
		RECT rcClient;
		int i;

		switch (uMsg)
		{
			/*case WM_CREATE:																// Create three invisible child windows.
			printf("Create Window");
			for (i = 0; i < 3; i++)
			{
			CreateWindowEx(0,
			"ChildWindow",
			(LPCTSTR)NULL,
			WS_CHILD | WS_BORDER,
			0, 0, 0, 0,
			_hwndMain,
			(HMENU)(int)(ID_FIRSTCHILD + i),
			appInstance,
			NULL);
			}
			return 0;


			case WM_SIZE:																	// main window changed size

			// Get the dimensions of the main window's client
			// area, and enumerate the child windows. Pass the
			// dimensions to the child windows during enumeration.
			GetClientRect(_hwndMain, &rcClient);
			EnumChildWindows(_hwndMain, EnumChildProc, (LPARAM)&rcClient);
			return 0;
			*/
		case WM_SIZE:
			printf("Resize");

		case WM_CLOSE:
			//When we resize, the function also get call
			// Create the message box. If the user clicks 
			// the Yes button, destroy the main window. 
			printf("Close Window");
			return 0;

		case WM_DESTROY:
			// Post the WM_QUIT message to 
			// quit the application terminate. 
			PostQuitMessage(0);
			return 0;

		case WM_CHAR: // character entered
			switch (wParam) // The character is in wParam
			{
			case VK_ESCAPE: // Exit program key // Tell Windows to kill this program	  
				PostQuitMessage(0);
				return 0;
			default:
				return 0;
			}
		}
		return DefWindowProc(_hwndMain, uMsg, wParam, lParam);
	}

	bool CreateMainWindow(HINSTANCE hInstance, int nCmdShow)
	{
		//--------------------------------------------------------------------
		// Creat a window class
		//--------------------------------------------------------------------
		WNDCLASSEX wcx{};
		// Fill in the window class structure with parameters 
		// that describe the main window. 
		// (19; List 2.3)
		wcx.cbSize = sizeof(wcx);                                                     // size of structure 
		wcx.style = CS_HREDRAW | CS_VREDRAW;                                          // redraw if size changes 
		wcx.lpfnWndProc = MainWndProc;                                                // points to window procedure 
		wcx.cbClsExtra = 0;                                                           // no extra class memory 
		wcx.cbWndExtra = 0;                                                           // no extra window memory 
		wcx.hInstance = hInstance;                                                    // handle to appInstance 
		wcx.hIcon = NULL;
		wcx.hCursor = LoadCursor(NULL, IDC_ARROW);                                    // predefined arrow 
		wcx.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);                      // black background brush 
		wcx.lpszMenuName = NULL;                                                      // name of menu resource 
		wcx.lpszClassName = CLASS_NAME;                                               // name of window class 
		wcx.hIconSm = NULL;                                                           // small class icon 


																					  // Register the window class. 
																					  // RegisterClassEx returns 0 on error. 
		if (RegisterClassEx(&wcx) == 0)    // if error
			return false;
		//set up the screen in windowed for fullscreen mode
		DWORD style;
		if (FULLSCREEN)
			style = WS_EX_TOPMOST | WS_VISIBLE | WS_POPUP;
		else
			style = WS_OVERLAPPEDWINDOW;                                     //overlapped window

																			 // Create window
		hwndMain = CreateWindow(
			CLASS_NAME,					                                     // name of the window class
			TITLE,						                                     // title bar text
			style,					                                         // window style
			CW_USEDEFAULT,                                                   // default horizontal position of window :0
			CW_USEDEFAULT,                                                   // default vertical position of window	:0
			WIDTH,                                                           // width of window
			HEIGHT,                                                          // height of the window
			(HWND)NULL,                                                      // no parent window
			(HMENU)NULL,                                                     // no menu
			hInstance,                                                       // handle to application appInstance. The application identifier from the Window class.
			(LPVOID)NULL);                                                   // no window parameters

																			 // if there was an error creating the window
		if (!hwndMain)
			return false;

		if (!FULLSCREEN)
		{
			// adjust window size so client area is GAME_WIDTH x GAME_HEIGHT
			RECT clientRect;                                                 //The RECT structure defines the coordinates of the upper-left and lower-right corners of a rectangle.
			GetClientRect(hwndMain, &clientRect);
			MoveWindow(hwndMain,
				0,	                                                         // left 
				0,                                                           // Top
				WIDTH + (WIDTH - clientRect.right),                          // Right
				HEIGHT + (HEIGHT - clientRect.bottom),                       // bottom
				true);
		}

		// Show the window
		ShowWindow(hwndMain, nCmdShow);

		// Send a WM_PAINT message to the window procedure
		UpdateWindow(hwndMain);
		return true;
	}

	void Application::InitOSWindow()
	{
		HINSTANCE appInstance = GetModuleHandle(nullptr);
		// Create the window
		if (!CreateMainWindow(appInstance, 10))											   //10 is the defult show
		{
			MessageBox(NULL, "Unable to create the Main Window", "Error", MB_OK);
			exit(0);
		}

		MSG	 msg;

		try
		{
			int shutDown = 0;
			while (!shutDown)
			{
				if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))                              // PeekMessage is a non-blocking method for checking for Windows messages.
				{
					if (msg.message == WM_QUIT)
						shutDown = 1;

					TranslateMessage(&msg);                                                //Decode the massage
					DispatchMessage(&msg);												   // Dispatch to the current fouced window
				}
				else
				{
					//Application::run();
				}
			}
			//Quit the Application
			return;
		}
		catch (const std::exception& e)
		{
			//Application::deleteAll();
			DestroyWindow(this->hwndMain);
			MessageBox(NULL, "Unknown error has occured in game.", "Error", MB_OK);
		}
	}

	void Application::ShutDownOSWidnow()
	{
	
	}

#endif
}