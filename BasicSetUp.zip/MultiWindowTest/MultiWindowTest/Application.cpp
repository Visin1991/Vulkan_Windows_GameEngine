#include "Application.h"


namespace VGameEngine
{
	void Application::InitialApp()
	{
		InitOSWindow();
	}

	void Application::ShutDownApp()
	{
		ShutDownOSWidnow();
	}
}