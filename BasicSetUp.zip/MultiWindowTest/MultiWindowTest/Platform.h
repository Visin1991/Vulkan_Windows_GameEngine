#pragma once
#include <map>
#include <set>
#include <list>
#include <array>
#include <cmath>
#include <ctime>
#include <vector>
#include <cassert>
#include <cstdlib>
#include <tchar.h>
#include <string>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <fstream>
#include <exception>
#include <algorithm>
#include <initializer_list>

#ifndef UNICODE
typedef std::string String;
#define to_String std::to_string
#else
typedef std::wstring String;
#define to_String std::to_wstring
#endif

#ifdef _WIN32 
#define VK_USE_PLATFORM_WIN32_KHR 1
#include <windows.h>
#elif defined( __linux )
#define VK_USE_PLATFORM_XCB_KHR 1
#include <xcb/xcb.h>
#else
#error Platform not yet supported
#endif
