#include "Platform.h"
#include "Application.h"

namespace VGameEngine
{
#if VK_USE_PLATFORM_XCB_KHR

#endif
}